import matplotlib.pyplot as plt
import numpy as np


a = np.load("/Users/oliversange/Desktop/BA_Desktop/Compressed simulations/data_2T_A_R9_run3/simulation_n=100_T_A=10_T_0=20_T_0_predator=10_R=5.612310241546865_dt=1e-05_steps=3000000_boundary_condition=True/eatings.npy")
print(np.shape(a))